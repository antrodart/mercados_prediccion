function changeLanguage(language) {
	document.getElementById("form_language_lang").value=language;
	document.getElementById("form_language").submit();
}