//Makes the <header> element stretch across the entire screen
//$(document).ready(function(){
//  $('.header').height($(window).height());
//})